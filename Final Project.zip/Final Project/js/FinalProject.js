var question = [];
function twentyQuestions(){
  var number = Number(prompt("Enter a number between 1 and 20."));
  var loopCounter = 1;
  var lastRandom;
  while(loopCounter <= 20){
    if(number < 1 || number > 20){
      alert("Your number is outside the specified range. Please try again.");
      number = Number(prompt("Enter a number between 1 and 20."));
    }else if(isNaN(number)){
      alert("You did not input a number. Please try again.");
      number = Number(prompt("Enter a number between 1 and 20."));
    }else
      loopCounter++;
    switch(number){
      case 1:
        question[0] = prompt("What is your name?");
        break;
      case 2:
        question[1] = prompt("What is your birthdate?");
        break;
      case 3:
        question[2] = prompt("What is your height?");
        break;
      case 4:
        question[3] = prompt("What is your weight?");
        break;
      case 5:
        question[4] = prompt("What year did you graduate high school? Write N/A if you haven't or didn't.");
        break;
      case 6:
        question[5] = prompt("What year did you graduate college? Write N/A if you haven't or didn't.");
        break;
      case 7:
        question[6] = prompt("Did you participate in sports in high school? If so, which ones?");
        break;
      case 8:
        question[7] = prompt("What is your favorite color?");
        break;
      case 9:
        question[8] = prompt("What is your favorite food?");
        break;
      case 10:
        question[9] = prompt("Do you have any hobbies? If so, what are they?");
        break;
      case 11:
        question[10] = prompt("If you could choose one superpower, what would it be?");
        break;
      case 12:
        question[11] = prompt("Do you have brothers or sisters? If so, how many?");
        break;
      case 13:
        question[12] = prompt("What is the greatest accomplishment of your life?");
        break;
      case 14:
        question[13] = prompt("What is the strangest food combination you enjoy?");
        break;
      case 15:
        question[14] = prompt("What family member are you closest to?");
        break;
      case 16:
        question[15] = prompt("What is the best place you ever traveled to?");
        break;
      case 17:
        question[16] = prompt("What is your most prized possession?");
        break;
      case 18:
        question[17] = prompt("Describe yourself in three words.");
        break;
      case 19:
        question[18] = prompt("What was your longest relationship?");
        break;
      case 20:
        question[19] = prompt("Would you rather sit in desks, at tables, on the floor, or in auditorium seats?");
        break;
      default:
        question = "That is an invalid number. Try again.";
    }
      var min = 1;
      var max = 20;
    if (lastRandom === undefined) {
    number = Math.floor(Math.random() * (max - min + 1)) + min;
}
else {
    number = Math.floor(Math.random() * (max - min)) + min;
    if (number >= lastRandom) number += 1;
}
lastRandom = number;
  }
}
function Main(){
  document.write(question);
}
twentyQuestions();
Main();  